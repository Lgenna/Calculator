package calc;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import calc.parser.Parser;
import calc.view.CalculatorView;


/**
 * 
 * @author Zachary Boone, V. Corina, Jonas Frankemolle, Luke Genna
 * @version May 7, 2019
 * 
 * Entry point of the program. Creates components and controls flow of user input.
 * */
public class Controller implements ActionListener{
	private CalculatorView v;
	
	/**
	 * entry point
	 */
	public static void main(String[] args) {
		new Controller();
	}
	
	/**
	 *  creates a new controller, initializing a GUI
	 *
	 */
	public Controller() {
		v = CalculatorView.createCalculator();	
		v.addComputeListener(this);
	} 
	
	@Override
	public void actionPerformed(ActionEvent e) {
		compute();
	}
	
	private void compute() {
		String input = v.getInput();
		String output = (new Parser(input)).solveFromString().toString();
		v.setInput(output);
	}
}

package calc.parser;

import java.util.ArrayList;
import java.util.PriorityQueue;

import calc.math.Matrix;
import calc.parser.tokens.Operator;
import calc.parser.tokens.OperatorTemplate;
import calc.parser.tokens.Token;
import calc.parser.tokens.TokenList;
import calc.parser.tokens.literals.Literal;
import calc.parser.tokens.literals.MatrixToken;
import calc.parser.tokens.literals.NumberToken;

/**
 * 
 * @author V. Corina
 * @version May 7, 2019
 * 
 * Responsible for tokenizing and evaluating the user's input.
 * 
 */
public class Parser {
	// the following regex splits at the first index of all non-digit characters
	// TODO: don't capture "-" with negative numbers
	// public static final String TOKENIZING_REGEX = "(?<=\\D(?<!-))|(?=\\D)";
	private static final String TOKENIZING_REGEX = "((?<=-?d)|(?=-?d))|((?<=\\D)|(?=\\D))";

	private final String input;
	private int index;
	private String[] splitInput;
	
	public Parser(String input) {
		this.input = input.replace(" ", "");;
	}

	/**
	 * Evaluates an expression in the form of a string and returns the result.
	 * 
	 * @param input the expression to be evaluated
	 * @return result
	 */
	public Literal solveFromString() {
		splitInput = input.split(TOKENIZING_REGEX);
		TokenList tokens = new TokenList();

		PriorityQueue<Operator> OperatorQueue = new PriorityQueue<Operator>();
		int depth = 0;
		for (index = 0; index < splitInput.length; index++) {
			String tokenString = splitInput[index];
			if (isOpenParen(tokenString)) {
				depth++;
			} else if (isCloseParen(tokenString)) {
				depth--;
			} else {
		
				Token toAdd = null;
				boolean isOperator = false;
				for (int j = 0; j < OperatorTemplate.OPERATORS_LOW_TO_HIGH_PRIORITY.length; j++) {

					int priority = j
							+ depth * OperatorTemplate.OPERATORS_LOW_TO_HIGH_PRIORITY.length;
					OperatorTemplate operatorTemplate = OperatorTemplate.OPERATORS_LOW_TO_HIGH_PRIORITY[j];

					if (tokenString.contentEquals(operatorTemplate.getSymbol() + "")) {
						Operator operator = operatorTemplate.creatOp(tokens.last());
						operator.setPriority(priority);
						OperatorQueue.add(operator);
						toAdd = operator;
						isOperator = true;
						break;
					}
				}
				if (!isOperator) {
					if (isOpenBracket(index))
						toAdd = buildMatrix();
					else {
						toAdd = new NumberToken(tokens.last(), null, Integer.parseInt(tokenString));		
					}
				}

				tokens.append(toAdd);
			}
		}
		tokens.printList();
		while (!OperatorQueue.isEmpty()) {
			OperatorQueue.poll().evaluate();
		}
		return (Literal) tokens.first();
	}

	private static boolean isOpenParen(String s) {
		return s.contentEquals("(");
	}

	private static boolean isCloseParen(String s) {
		return s.contentEquals(")");
	}


	private MatrixToken buildMatrix() {
		ArrayList<ArrayList<Integer>> rows = new ArrayList<ArrayList<Integer>>();
		System.out.println("new matrix:");
		int matrixIndex = index+1;

		while (!endOfMatrix(matrixIndex)) {
			
			System.out.println("Token to test " + splitInput[matrixIndex]);
			if (shouldIgnoreToken(matrixIndex)) {

				System.out.println("token ignored");
				// do nothing
			} else if (isOpenBracket(matrixIndex)) {
				// new row
				System.out.println("new row");
			
				rows.add(new ArrayList<Integer>());
			} else {
				int val = Integer.parseInt(splitInput[matrixIndex]);
				rows.get(rows.size() - 1).add(val);
				System.out.println("adding new num to matrix: " + val);
			}
			matrixIndex++;

		}


		int rowSize = rows.size();
		int columnSize = rows.get(0).size();
		int[][] data = new int[rowSize][columnSize];

		for (int i = 0; i < rowSize; i++) {
			for (int j = 0; j < columnSize; j++) {
				data[i][j] = rows.get(i).get(j);
			}
		}
		MatrixToken m = new MatrixToken(new Matrix(data));
		System.out.println(m);
		index = matrixIndex+1;
		return m;
	}

	private boolean endOfMatrix(int i) {
		
		boolean result = isCloseBracket(i) && isCloseBracket(i+1);
	
		return result;
	}

	private boolean isOpenBracket(int i) {
		return splitInput[i].contentEquals("[");
	}

	private boolean isCloseBracket(int i) {
		return splitInput[i].contentEquals("]");
	}

	private boolean shouldIgnoreToken(int i) {
		return isCloseBracket(i) || splitInput[i].contentEquals(",");
	}

}

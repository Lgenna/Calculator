package calc.parser.tokens.literals;

import calc.math.Matrix;

/**
 * 
 * @author V. Corina
 * Token class to represent Matrices in an expression. Primarily an adapter for the calc.math library.
 */
public class MatrixToken extends Literal {

	/**
	 * Creates a MatrixToken from a Matrix data object
	 * @param m
	 */
	public MatrixToken(Matrix m) {
		super(null);
		this.m = m;
	}
	private Matrix m;

	/**
	 * Gets the tokens internal Matrix data
	 * @return
	 */
	public Matrix getMatrix() {
		return m;
	}

	@Override
	public String toString() {
		return m.toString();
	}

	@Override
	public Literal plus(Literal b) {
		MatrixToken addend = (MatrixToken) b;
		return new MatrixToken(Matrix.add(m, addend.m));
	}

	@Override
	public Literal times(Literal b) {
		if (b instanceof MatrixToken) {
			MatrixToken multiplier = (MatrixToken) b;
			return new MatrixToken(Matrix.multiply(m, multiplier.m));
		} else {
			throw new RuntimeException("Illegal argument types.");
		}

	}

	@Override
	public Literal minus(Literal b) {
		if (b instanceof MatrixToken) {
			MatrixToken subtrahend = (MatrixToken) b;
			return new MatrixToken(Matrix.subtract(m, subtrahend.m));
		} else {
			throw new RuntimeException("Illegal argument types.");
		}

	}

	@Override
	public Literal dot(Literal b) {
		if (b instanceof MatrixToken) {
			MatrixToken secondMatrix = (MatrixToken) b;
			return new NumberToken(Matrix.dotProduct(m, secondMatrix.m));

		} else {
			throw new RuntimeException("Illegal argument types.");
		}
	}

	@Override
	public Literal cross(Literal b) {
		if (b instanceof MatrixToken) {
			MatrixToken secondMatrix = (MatrixToken) b;
			return new MatrixToken(Matrix.crossProduct(m, secondMatrix.m));

		} else {
			throw new RuntimeException("Illegal argument types.");
		}

	}

	@Override
	public Literal toThePowerOf(Literal b) {
		NumberToken exponent = (NumberToken) b;
		return new MatrixToken(Matrix.power(m, exponent.getVal()));
	}



	@Override
	public Literal dividedBy(Literal b) {
		// TODO Auto-generated method stub
		return null;
	}

}

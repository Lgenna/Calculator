package calc.parser.tokens.literals;

import calc.parser.tokens.Token;
/**
 * 
 * @author V. Corina
 * Class to represent literal values in an expression
 */
public abstract class Literal extends Token{
	/**
	 * Creates a new Literal
	 * @param left token to the left of the literal
	 * @param right token to the right of the literal 
	 */
	public Literal(Token left, Token right) {
		super(left, right);
	}
	/**
	 * Creates a new Literal
	 * @param left token to the left of the literal
	 */
	public Literal(Token left) {
		super(left, null);
	}
	
	/**
	 * Adds one literal to another
	 * @param addend
	 * @return the sum
	 */
	public abstract Literal plus(Literal addend);
	
	/**
	 * Subtracts one literal from another
	 * @param subtrahend
	 * @return the difference
	 */
	public abstract Literal minus(Literal subtrahend);
	/**
	 * Multiplies one literal by another
	 * @param multiplier
	 * @return the product
	 */
	public abstract Literal times(Literal multiplier);
	/**
	 * Finds the dot product of two literals
	 * @param b the second literal
	 * @return the dot product of this literal and b
	 */
	public abstract Literal dot(Literal b);
	/**
	 * Divides one literal by another
	 * @param divisor
	 * @return the quotient
	 */
	public abstract Literal dividedBy(Literal divisor);
	/**
	 * Finds the cross product of two literals
	 * @param b the second literal
	 * @return the cross product of this literal and b
	 */
	public abstract Literal cross(Literal b);
	/**
	 * exponentiates 
	 * @param exponent
	 * @return the power
	 */
	public abstract Literal toThePowerOf(Literal b);
	
	

}

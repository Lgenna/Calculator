package calc.parser.tokens.literals;

import calc.math.Matrix;
import calc.parser.tokens.Token;
/**
 * 
 * @author V. Corina
 * Token class to represent numbers in an expression. 
 */
public class NumberToken extends Literal{
	private int val;
	
	/**
	 * Creates a new NumberToken
	 * @param left the left neighbor
	 * @param right the right neighbor
	 * @param val the integer value
	 */
	public NumberToken(Token left, Token right, int val) {
		super(left, right);
			this.val = val;	
	}
	/**
	 * Creates a new NumberToken
	 * @param val the integer value
	 */
	public NumberToken(int val) {
		super(null, null);
		this.val = val;	
	}
	
	@Override
	public String toString() {
		return ""+val;	
	}
	
	@Override
	public Literal plus(Literal addend) {
		
		if (addend instanceof NumberToken) {
			NumberToken b = (NumberToken) addend;
			return new NumberToken(val + b.val);	
		} else {
			throw new RuntimeException("Illegal attempt to add integer to matrix.");
		}
	}

	@Override
	public Literal times(Literal multiplier) {
		if (multiplier instanceof NumberToken) {
			NumberToken b = (NumberToken) multiplier;
			return new NumberToken(left, right, val * b.val);
		} else if (multiplier instanceof MatrixToken) {
			MatrixToken b = (MatrixToken) multiplier;
			return new MatrixToken(Matrix.scalarMatrix(val, b.getMatrix()));
		} 
		throw new RuntimeException("Illegal argument types.");
		
		
	}

	@Override
	public Literal toThePowerOf(Literal power) {
		NumberToken b = (NumberToken) power;
		return new NumberToken(left,right,(int)Math.pow(val,b.val));
	}
	@Override
	public Literal minus(Literal subtrahend) {

		if (subtrahend instanceof NumberToken) {
			NumberToken b = (NumberToken) subtrahend;
			return new NumberToken(left, right, val - b.val);	
		} else {
			throw new RuntimeException("Illegal attempt to add integer to matrix.");
		}
	}
	@Override
	public Literal dot(Literal b) {
		throw new RuntimeException("Illegal argument types.");
		
	}
	@Override
	public Literal cross(Literal b) {
		throw new RuntimeException("Illegal argument types.");
		
	}

	/**
	 * Retrieves the NumberToken integer value 
	 * @return the value
	 */
	public int getVal() {
		return val;
	}

	@Override
	public Literal dividedBy(Literal b) {
		if (b instanceof NumberToken) {

			NumberToken d = (NumberToken) b;
			return new NumberToken(left,right,this.val/d.getVal());
		} else {
			throw new RuntimeException("Illegal attempt to add integer to matrix.");
		}
		
	}

}

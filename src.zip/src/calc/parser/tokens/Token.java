package calc.parser.tokens;

/**
 * 
 * @author V. Corina
 * 
 *         Stores expression data in a double-linked-list node
 */
public abstract class Token {
	protected Token left, right;

	/**
	 * creates a new token
	 * 
	 * @param left  the token's left neighbor
	 * @param right the token's right neighbor
	 */
	public Token(Token left, Token right) {
		this.left = left;
		this.right = right;
	}

	/**
	 * creates a new token
	 * 
	 * @param left  the token's left neighbor
	 * @param right the token's right neighbor
	 */
	public Token() {
	}

	/**
	 * 
	 * @return the token's right neighbor
	 */
	public Token getRight() {
		return right;

	}

	/**
	 * 
	 * @return the token's left neighbor
	 */
	public Token getLeft() {
		return left;
	}

	/**
	 * Setter for the the right neighbor
	 * @param right the new right neighbor 
	 */
	public void setRight(Token right) {
		this.right = right;
	}


	/**
	 * Setter for the the left neighbor
	 * @param right the new left neighbor 
	 */
	public void setLeft(Token left) {
		this.left = left;
	}

	/**
	 * removes the token's left neighbor without removing it from the list
	 */
	public void removeLeft() {
		if (left.left != null) {
			left.left.right = this;
			left = left.left;
		}
	}
	/**
	 * removes the token's left neighbor without removing it from the list
	 */
	public void removeRight() {
		if (right.right != null) {
			right.right.left = this;
			right = right.right;
		}
	}

	protected void printNeighbors() {
		System.out.println("left: " + left);
		System.out.println("right: " + right);

	}

	protected void replaceThisToken(Token token) {

		left.right = token;
		right.left = token;
		token.left = left;
		token.right = right;

	}

}

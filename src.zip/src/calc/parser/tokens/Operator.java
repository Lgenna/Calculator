package calc.parser.tokens;

import java.util.function.BiFunction;

import calc.parser.tokens.literals.Literal;

/**
 * 
 * @author V. Corina
 *
 * Represents an operation to be applied to two literals
 */
public class Operator extends Token implements Comparable<Operator> {

	private BiFunction<Token, Token, Literal> operation;
	private char symbol;
	
	/**
	 * Creates a new Operator
	 * 
	 * @param symbol    character representation of the operation
	 * @param operation function to be applied
	 * @param left      the neighbor to its left
	 */
	public Operator(char symbol, BiFunction<Token, Token, Literal> operation, Token left) {
		super(left, null);
		this.symbol = symbol;
		this.operation = operation;
	}



	/**
	 * Applies the operation to its neighbors in the linked list, inserting the
	 * result into the chain
	 */
	public void evaluate() {
		Token result = operation.apply(left, right);
		removeLeft();
		removeRight();
		replaceThisToken(result);

	}

	protected int priority;

	/**
	 * Sets Operator's priority
	 * 
	 * @param priority
	 */
	public void setPriority(int priority) {
		this.priority = priority;
	}

	@Override
	public int compareTo(Operator o) {
		return Integer.compare(o.priority, priority);
	}

	@Override
	public String toString() {
		return "" + symbol;
	}

	
}

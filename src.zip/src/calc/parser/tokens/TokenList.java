package calc.parser.tokens;
/**
 * 
 * @author V. Corina
 * 
 * Stores tokens in a doubly linked list
 */
public class TokenList extends Token {
	private Token last;
	private Token end;
	private static class END_OF_LIST extends Token {
		public String toString() {
			return "}";
		}
	}


	/**
	 * Creates a new, empty TokenList
	 */
	public TokenList() {
		end = new END_OF_LIST();
		right = end;
		end.left = right;
		last = this;
	}

	/**
	 * Prints the contents of the list
	 */
	public void printList() {
		String s = "{";
		Token node = right;
		while (node!=null) {
			s+= node;
			node = node.right;
		}
		System.out.println(s);
	}

	/**
	 * 
	 * @return the first token in the list
	 */
	public Token first() {
		return right;
	}

	/**
	 * 
	 * @return the last token in the list
	 */
	public Token last() {
		return last;
	}

	/**
	 * adds a token to the end of the list
	 * @param token the token to be added
	 */
	public void append(Token token) {
		if (last == null) {
			insertAt(this.right, token);
		}
		insertAt(last, token);
		last = token;
	}

	private void insertAt(Token a, Token b) {
		a.right.left = b;
		b.right = a.right;

		b.left = a;
		a.right = b;

	}

}

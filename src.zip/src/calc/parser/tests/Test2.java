package calc.parser.tests;

public class Test2 {
	public static void main(String[] args) {

	}
}
@FunctionalInterface
interface Function<Token> {
    public Token apply(Token left,Token right);
}

